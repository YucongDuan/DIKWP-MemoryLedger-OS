# Security Policy

Report vulnerabilities responsibly. This repository intentionally avoids network access, credential storage, hidden persistence, or automatic exfiltration.

If a proposed change stores sensitive data, it must include:

- explicit consent state,
- retention duration,
- export path,
- deletion path,
- audit event,
- test coverage.
