from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class SourceSpan:
    source_id: str
    line_start: int
    line_end: int
    text: str


@dataclass
class MemoryCandidate:
    memory_id: str
    subject: str
    text: str
    memory_type: str
    confidence: float
    source: SourceSpan
    dikwp: Dict[str, Any]
    risks: List[str] = field(default_factory=list)
    reliability: str = "Provisional"
    consent_state: str = "unknown"
    retention_days: int = 90
    review_required: bool = True
    created_at: str = field(default_factory=utcnow)
    expires_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MemoryDecision:
    memory_id: str
    decision: str
    reason: str
    risk_score: float
    recommended_retention_days: int
    kill_conditions: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
