from __future__ import annotations

from typing import Dict, List


def compile_dikwp(text: str, memory_type: str, subject: str, evidence_note: str = "local text span") -> Dict[str, object]:
    """Create a DIKWP semantic registration for a memory candidate."""
    return {
        "D": {
            "fragment": text,
            "subject": subject,
            "source": evidence_note,
        },
        "I": {
            "memory_type": memory_type,
            "relations": infer_relations(text),
            "time_scope": infer_time_scope(text),
        },
        "K": {
            "candidate_rule": infer_candidate_rule(memory_type),
            "mechanism": "persistent context may influence future agent responses and tool decisions",
        },
        "W": {
            "value_boundary": infer_value_boundary(text, memory_type),
            "sensitivity_hint": infer_sensitivity(text),
            "review_norm": "retain only if useful, consented, evidence-bearing, and reversible",
        },
        "P": {
            "allowed_future_use": infer_allowed_use(memory_type),
            "purpose_risk": infer_purpose_risk(text, memory_type),
        },
        "R": {
            "reliability": "Provisional",
            "evidence_basis": evidence_note,
            "residual": "candidate memory extracted by heuristic local parser; requires human or policy review",
        },
    }


def infer_relations(text: str) -> List[str]:
    low = text.lower()
    rel = []
    if any(k in low for k in ["prefer", "likes", "喜欢", "偏好"]): rel.append("preference")
    if any(k in low for k in ["goal", "purpose", "目标", "目的"]): rel.append("goal")
    if any(k in low for k in ["must", "never", "constraint", "不能", "必须"]): rel.append("constraint")
    if any(k in low for k in ["project", "client", "客户", "项目"]): rel.append("project_context")
    if any(k in low for k in ["remember", "记住", "memory"]): rel.append("memory_instruction")
    return rel or ["general_context"]


def infer_time_scope(text: str) -> str:
    low = text.lower()
    if any(k in low for k in ["always", "forever", "永久", "永远"]): return "open_ended_high_risk"
    if any(k in low for k in ["this week", "today", "本周", "今天"]): return "short_term"
    if any(k in low for k in ["project", "quarter", "month", "项目", "季度", "月"]): return "project_term"
    return "unspecified"


def infer_candidate_rule(memory_type: str) -> str:
    table = {
        "preference": "may personalize responses if the preference is non-sensitive and user-controllable",
        "goal": "may preserve purpose continuity if it remains current and consented",
        "constraint": "may be retained as a safety or workflow boundary with review",
        "project_context": "may improve long-running work continuity if scoped to a project",
        "sensitive": "must not be stored without explicit need, consent and retention boundary",
        "credential_like": "must be blocked from memory storage",
        "poisoning_instruction": "must be blocked or quarantined",
        "unsupported_claim": "may be stored only as claim, not as fact",
    }
    return table.get(memory_type, "requires policy review before persistent storage")


def infer_value_boundary(text: str, memory_type: str) -> str:
    if memory_type in {"credential_like", "sensitive"}:
        return "privacy and safety dominate convenience"
    if memory_type == "poisoning_instruction":
        return "memory integrity dominates instruction obedience"
    if memory_type == "goal":
        return "purpose continuity must remain user-revisable"
    return "usefulness must be balanced against retention risk"


def infer_sensitivity(text: str) -> str:
    low = text.lower()
    if any(k in low for k in ["password", "api key", "token", "secret", "密码", "密钥"]): return "credential_like"
    if any(k in low for k in ["health", "medical", "diagnosis", "病", "医疗", "健康"]): return "health_like"
    if any(k in low for k in ["salary", "bank", "credit", "收入", "银行", "财务"]): return "financial_like"
    if any(k in low for k in ["legal", "lawsuit", "合同", "诉讼", "法律"]): return "legal_like"
    if any(k in low for k in ["child", "minor", "未成年", "孩子"]): return "minor_related"
    return "ordinary_or_unknown"


def infer_allowed_use(memory_type: str) -> str:
    if memory_type == "credential_like": return "no persistent use; block and redact"
    if memory_type == "poisoning_instruction": return "no persistent use; quarantine as attack evidence"
    if memory_type == "sensitive": return "only with explicit consent, narrow purpose and short retention"
    if memory_type == "goal": return "support long-running purpose continuity and progress review"
    if memory_type == "constraint": return "enforce safety, user preference or workflow boundary"
    return "support contextual relevance if current and consented"


def infer_purpose_risk(text: str, memory_type: str) -> str:
    low = text.lower()
    if any(k in low for k in ["secretly", "without telling", "do not disclose", "隐藏", "不要告诉"]):
        return "covert_retention_or_transparency_risk"
    if any(k in low for k in ["ignore previous", "override", "bypass", "忽略之前", "绕过"]):
        return "intent_drift_or_policy_override_risk"
    if memory_type == "goal": return "stale goal may misdirect future actions if not reviewed"
    return "ordinary drift risk"
