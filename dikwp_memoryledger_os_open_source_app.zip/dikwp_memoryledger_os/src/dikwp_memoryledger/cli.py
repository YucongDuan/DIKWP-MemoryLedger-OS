from __future__ import annotations

import argparse
import json
from pathlib import Path

from .analyzer import extract_from_file
from .ledger import MemoryLedger
from .reports import recommendations_md
from .static_audit import audit_source_tree


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def cmd_analyze(args) -> None:
    out = Path(args.out)
    candidates = extract_from_file(args.input, subject=args.subject)
    ledger = MemoryLedger(args.subject)
    ledger.add_candidates(candidates)
    write_json(out / "memory_ledger.json", ledger.to_ledger())
    risk_report = ledger.risk_report()
    purpose_map = ledger.purpose_map()
    write_json(out / "memory_risk_report.json", risk_report)
    write_json(out / "purpose_continuity_map.json", purpose_map)
    write_json(out / "context_pack.json", ledger.context_pack())
    write_json(out / "dsar_export.json", ledger.dsar_export())
    (out / "recommendations.md").write_text(recommendations_md(risk_report, purpose_map), encoding="utf-8")
    print(json.dumps({"status":"ok", "summary": risk_report["summary"], "out": str(out)}, ensure_ascii=False, indent=2))


def cmd_static_audit(args) -> None:
    report = audit_source_tree(args.root)
    if args.out:
        write_json(Path(args.out), report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="dikwp-memoryledger")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze", help="Analyze a memory source file")
    a.add_argument("input")
    a.add_argument("--subject", default="unknown")
    a.add_argument("--out", default="outputs/demo")
    a.set_defaults(func=cmd_analyze)
    s = sub.add_parser("static-audit", help="Run static safety boundary audit")
    s.add_argument("root")
    s.add_argument("--out")
    s.set_defaults(func=cmd_static_audit)
    return p


def main(argv=None) -> None:
    args = build_parser().parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
