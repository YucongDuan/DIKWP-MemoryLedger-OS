from __future__ import annotations

import ast
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "requests", "urllib", "subprocess", "paramiko", "ftplib"}
FORBIDDEN_CALLS = {"os.system", "subprocess.run", "subprocess.Popen", "eval", "exec"}


def audit_source_tree(root: str | Path) -> Dict[str, object]:
    root = Path(root)
    findings: List[Dict[str, str]] = []
    for path in root.rglob("*.py"):
        if "tests" in path.parts:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception as e:
            findings.append({"file": str(path), "type": "parse_error", "detail": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root_name = alias.name.split(".")[0]
                    if root_name in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root_name = node.module.split(".")[0]
                    if root_name in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": node.module})
            elif isinstance(node, ast.Call):
                name = None
                if isinstance(node.func, ast.Name):
                    name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    base = node.func.value.id if isinstance(node.func.value, ast.Name) else None
                    if base:
                        name = f"{base}.{node.func.attr}"
                if name in FORBIDDEN_CALLS:
                    findings.append({"file": str(path), "type": "forbidden_call", "detail": name})
    return {"pass": len(findings) == 0, "finding_count": len(findings), "findings": findings}
