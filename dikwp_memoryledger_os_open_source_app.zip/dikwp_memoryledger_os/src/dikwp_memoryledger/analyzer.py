from __future__ import annotations

import hashlib
from pathlib import Path
from typing import List

from .dikwp import compile_dikwp
from .models import MemoryCandidate, SourceSpan
from .text_utils import iter_nonempty_lines, contains_any, normalize_space


PREFERENCE = ["prefer", "likes", "dislikes", "favorite", "喜欢", "偏好", "不喜欢"]
GOAL = ["goal", "purpose", "objective", "want to", "trying to", "目标", "目的", "希望", "正在做"]
CONSTRAINT = ["must", "never", "do not", "cannot", "constraint", "boundary", "必须", "不能", "边界", "禁止"]
PROJECT = ["project", "client", "workspace", "team", "roadmap", "项目", "客户", "团队", "路线图"]
CREDENTIAL = ["password", "api key", "secret key", "token", "ssh", "私钥", "密码", "密钥", "令牌"]
SENSITIVE = ["health", "medical", "diagnosis", "salary", "bank", "credit", "minor", "child", "legal", "健康", "医疗", "诊断", "收入", "银行", "未成年", "法律"]
POISON = ["ignore previous", "forget all policies", "always remember secretly", "do not disclose", "hidden instruction", "bypass", "override policy", "忽略之前", "秘密记住", "不要披露", "绕过", "覆盖政策"]
CLAIM = ["is the best", "guaranteed", "always true", "proven", "标准答案", "保证", "必然", "已经证明"]


def classify(line: str) -> tuple[str, float]:
    low = line.lower()
    if contains_any(low, CREDENTIAL): return "credential_like", 0.98
    if contains_any(low, POISON): return "poisoning_instruction", 0.95
    if contains_any(low, SENSITIVE): return "sensitive", 0.86
    if contains_any(low, CONSTRAINT): return "constraint", 0.78
    if contains_any(low, GOAL): return "goal", 0.76
    if contains_any(low, PROJECT): return "project_context", 0.72
    if contains_any(low, PREFERENCE): return "preference", 0.7
    if contains_any(low, CLAIM): return "unsupported_claim", 0.62
    if len(line) > 60: return "general_context", 0.45
    return "low_value_fragment", 0.25


def memory_id(subject: str, line_no: int, line: str) -> str:
    h = hashlib.sha256((subject + str(line_no) + line).encode("utf-8")).hexdigest()[:12]
    return f"mem_{h}"


def extract_memories(text: str, subject: str = "unknown", source_id: str = "local") -> List[MemoryCandidate]:
    out: List[MemoryCandidate] = []
    for line_no, raw in iter_nonempty_lines(text):
        line = normalize_space(raw)
        mtype, conf = classify(line)
        if mtype == "low_value_fragment" and conf < 0.35:
            continue
        span = SourceSpan(source_id=source_id, line_start=line_no, line_end=line_no, text=line)
        dikwp = compile_dikwp(line, mtype, subject, evidence_note=f"{source_id}:L{line_no}")
        out.append(MemoryCandidate(
            memory_id=memory_id(subject, line_no, line),
            subject=subject,
            text=line,
            memory_type=mtype,
            confidence=conf,
            source=span,
            dikwp=dikwp,
        ))
    return out


def extract_from_file(path: str | Path, subject: str = "unknown") -> List[MemoryCandidate]:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    return extract_memories(text, subject=subject, source_id=p.name)
