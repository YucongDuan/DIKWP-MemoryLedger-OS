from __future__ import annotations

from typing import Dict


def recommendations_md(risk_report: Dict, purpose_map: Dict) -> str:
    s = risk_report["summary"]
    lines = [
        "# DIKWP MemoryLedger Recommendations",
        "",
        f"Subject: `{risk_report['subject']}`",
        "",
        "## Summary",
        "",
        f"- Candidate memories: {s['candidate_count']}",
        f"- Allowed: {s['allow_count']}",
        f"- Review: {s['review_count']}",
        f"- Blocked: {s['block_count']}",
        f"- Mean risk score: {s['mean_risk_score']}",
        "",
        "## Recommended actions",
        "",
    ]
    if s["block_count"]:
        lines.append("- Remove blocked memories from persistent storage. They may be retained only as attack evidence if strictly necessary and isolated.")
    if s["review_count"]:
        lines.append("- Review uncertain or sensitive memories before future use. Ask the subject or responsible owner to confirm purpose, scope and retention.")
    if s["allow_count"]:
        lines.append("- Use allowed memories only inside the context pack boundary and respect expiry dates.")
    lines += [
        "- Keep source spans and evidence custody attached to every memory.",
        "- Re-run the ledger after major project changes, policy changes or user preference updates.",
        "- Do not let memory become a silent authority; every memory must remain inspectable and forgettable.",
        "",
        "## DIKWP boundary",
        "",
        "Memory is not truth by default. It is a time-carrying semantic object that can become stale, poisoned, incomplete or mis-scoped.",
    ]
    return "\n".join(lines) + "\n"
