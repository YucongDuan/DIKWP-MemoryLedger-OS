from __future__ import annotations

import re
from typing import Iterable, List, Tuple


def normalize_space(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def iter_nonempty_lines(text: str) -> Iterable[Tuple[int, str]]:
    for idx, line in enumerate(text.splitlines(), start=1):
        line = line.strip()
        if line:
            yield idx, line


def contains_any(text: str, patterns: List[str]) -> bool:
    t = text.lower()
    return any(p.lower() in t for p in patterns)


def slugish(text: str, max_len: int = 64) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text.lower()).strip("-")
    return text[:max_len] or "item"
