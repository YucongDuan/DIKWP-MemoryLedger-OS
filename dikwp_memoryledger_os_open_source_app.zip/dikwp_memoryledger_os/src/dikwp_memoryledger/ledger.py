from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List

from .models import MemoryCandidate, MemoryDecision
from .risk import assess_candidate, apply_decision


class MemoryLedger:
    def __init__(self, subject: str):
        self.subject = subject
        self.candidates: List[MemoryCandidate] = []
        self.decisions: List[MemoryDecision] = []

    def add_candidates(self, candidates: List[MemoryCandidate]) -> None:
        for c in candidates:
            d = assess_candidate(c)
            c2 = apply_decision(c, d)
            self.candidates.append(c2)
            self.decisions.append(d)

    def allowed_memories(self) -> List[MemoryCandidate]:
        return [c for c, d in zip(self.candidates, self.decisions) if d.decision == "allow"]

    def blocked_memories(self) -> List[MemoryCandidate]:
        return [c for c, d in zip(self.candidates, self.decisions) if d.decision == "block"]

    def review_memories(self) -> List[MemoryCandidate]:
        return [c for c, d in zip(self.candidates, self.decisions) if d.decision == "review"]

    def to_ledger(self) -> Dict[str, Any]:
        return {
            "subject": self.subject,
            "summary": self.summary(),
            "memories": [c.to_dict() for c in self.candidates],
            "decisions": [d.to_dict() for d in self.decisions],
        }

    def summary(self) -> Dict[str, Any]:
        n = len(self.candidates)
        allow = sum(1 for d in self.decisions if d.decision == "allow")
        review = sum(1 for d in self.decisions if d.decision == "review")
        block = sum(1 for d in self.decisions if d.decision == "block")
        risk = round(sum(d.risk_score for d in self.decisions) / n, 3) if n else 0.0
        return {
            "candidate_count": n,
            "allow_count": allow,
            "review_count": review,
            "block_count": block,
            "mean_risk_score": risk,
        }

    def risk_report(self) -> Dict[str, Any]:
        categories = {}
        for c, d in zip(self.candidates, self.decisions):
            categories.setdefault(c.memory_type, {"count":0, "avg_risk":0.0, "decisions": {}})
            categories[c.memory_type]["count"] += 1
            categories[c.memory_type]["avg_risk"] += d.risk_score
            categories[c.memory_type]["decisions"][d.decision] = categories[c.memory_type]["decisions"].get(d.decision, 0) + 1
        for item in categories.values():
            item["avg_risk"] = round(item["avg_risk"] / item["count"], 3)
        return {"subject": self.subject, "summary": self.summary(), "by_memory_type": categories}

    def purpose_map(self) -> Dict[str, Any]:
        goals = []
        constraints = []
        values = []
        for c, d in zip(self.candidates, self.decisions):
            if d.decision == "block":
                continue
            if c.memory_type == "goal": goals.append(c.to_dict())
            if c.memory_type == "constraint": constraints.append(c.to_dict())
            values.append({"memory_id": c.memory_id, "type": c.memory_type, "W": c.dikwp.get("W"), "P": c.dikwp.get("P"), "R": c.dikwp.get("R")})
        return {
            "subject": self.subject,
            "purpose_continuity": {
                "goals": goals,
                "constraints": constraints,
                "value_and_purpose_register": values,
                "residual": "Purpose continuity is useful only if the subject can inspect, revise and delete memories."
            }
        }

    def context_pack(self) -> Dict[str, Any]:
        return {
            "context_pack_version": "dikwp-memoryledger-os-0.1",
            "subject": self.subject,
            "usage_boundary": "Only use allowed memories for the stated purpose; do not infer sensitive traits beyond the ledger.",
            "allowed_memories": [
                {
                    "memory_id": c.memory_id,
                    "type": c.memory_type,
                    "text": c.text,
                    "allowed_use": c.dikwp["P"]["allowed_future_use"],
                    "expires_at": c.expires_at,
                    "reliability": c.reliability,
                    "source": c.source.__dict__,
                } for c in self.allowed_memories()
            ],
            "review_queue": [{"memory_id": c.memory_id, "type": c.memory_type, "text": c.text, "reliability": c.reliability} for c in self.review_memories()],
            "blocked_memories_count": len(self.blocked_memories()),
        }

    def dsar_export(self) -> Dict[str, Any]:
        return {
            "subject": self.subject,
            "export_type": "memory_access_and_deletion_review_bundle",
            "memories": [c.to_dict() for c in self.candidates],
            "deletion_candidates": [c.memory_id for c, d in zip(self.candidates, self.decisions) if d.decision in {"block", "review"}],
            "notes": "This is not legal advice. It is a technical memory ledger export for privacy and governance review."
        }
