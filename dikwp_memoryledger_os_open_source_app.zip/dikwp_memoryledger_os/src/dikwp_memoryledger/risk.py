from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import List

from .models import MemoryCandidate, MemoryDecision


HIGH_RISK_TYPES = {"credential_like", "poisoning_instruction"}
SENSITIVE_TYPES = {"sensitive"}
REVIEW_TYPES = {"unsupported_claim", "general_context"}


def assess_candidate(candidate: MemoryCandidate) -> MemoryDecision:
    risk_score = 0.0
    reasons: List[str] = []
    kill: List[str] = []
    decision = "allow"
    retention = 180

    if candidate.memory_type in HIGH_RISK_TYPES:
        risk_score = 1.0
        decision = "block"
        retention = 0
        reasons.append(f"{candidate.memory_type} must not become persistent memory")
        kill.append("persistent storage requested for credential-like or poisoning instruction")
    elif candidate.memory_type in SENSITIVE_TYPES:
        risk_score = 0.78
        decision = "review"
        retention = 30
        reasons.append("sensitive-like memory requires explicit consent, narrow purpose and short retention")
        kill.append("no explicit consent or purpose limitation")
    elif candidate.memory_type == "unsupported_claim":
        risk_score = 0.62
        decision = "review"
        retention = 60
        reasons.append("claim-like memory needs evidence; store as claim, not fact")
        kill.append("unsupported claim used as factual memory")
    elif candidate.memory_type == "goal":
        risk_score = 0.35
        decision = "allow"
        retention = 180
        reasons.append("goal memory supports purpose continuity but needs review for staleness")
        kill.append("goal no longer endorsed by subject")
    elif candidate.memory_type == "constraint":
        risk_score = 0.32
        decision = "allow"
        retention = 180
        reasons.append("constraint memory can protect boundaries if it remains current")
        kill.append("constraint contradicts newer explicit instruction")
    elif candidate.memory_type == "preference":
        risk_score = 0.28
        decision = "allow"
        retention = 365
        reasons.append("ordinary preference may personalize if user-controllable")
        kill.append("preference is inferred incorrectly or becomes sensitive")
    elif candidate.memory_type == "project_context":
        risk_score = 0.3
        decision = "allow"
        retention = 180
        reasons.append("project context supports continuity but should expire after project term")
        kill.append("project closed or context obsolete")
    else:
        risk_score = 0.45
        decision = "review"
        retention = 90
        reasons.append("general context has unclear future usefulness")
        kill.append("memory usefulness cannot be justified")

    if "covert" in candidate.dikwp["P"].get("purpose_risk", "") or "override" in candidate.dikwp["P"].get("purpose_risk", ""):
        risk_score = max(risk_score, 0.9)
        decision = "block" if candidate.memory_type in HIGH_RISK_TYPES else "review"
        reasons.append("purpose-risk signal indicates covert retention or policy override")
        kill.append("memory attempts to change governance without consent")

    return MemoryDecision(
        memory_id=candidate.memory_id,
        decision=decision,
        reason="; ".join(reasons),
        risk_score=round(risk_score, 3),
        recommended_retention_days=retention,
        kill_conditions=kill,
    )


def apply_decision(candidate: MemoryCandidate, decision: MemoryDecision) -> MemoryCandidate:
    candidate.risks = decision.kill_conditions
    candidate.retention_days = decision.recommended_retention_days
    candidate.review_required = decision.decision != "allow"
    candidate.reliability = "Blocked" if decision.decision == "block" else ("Provisional" if decision.decision == "review" else "Supported")
    if decision.decision == "block":
        candidate.consent_state = "not_applicable_blocked"
        candidate.expires_at = None
    else:
        candidate.consent_state = "explicit_or_required"
        candidate.expires_at = (datetime.now(timezone.utc) + timedelta(days=decision.recommended_retention_days)).isoformat()
    candidate.dikwp["R"]["reliability"] = candidate.reliability
    candidate.dikwp["R"]["kill_conditions"] = decision.kill_conditions
    candidate.dikwp["R"]["expires_at"] = candidate.expires_at
    return candidate
