# Code of Conduct

Be precise, constructive and evidence-oriented. This project is a governance tool, not a persuasion or surveillance tool.
