from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from pathlib import Path
from dikwp_memoryledger.analyzer import extract_memories
from dikwp_memoryledger.ledger import MemoryLedger
from dikwp_memoryledger.static_audit import audit_source_tree


def test_extract_and_block_secret():
    text = "Remember this forever: the API key is sk-test-secret.\nThe user goal is to launch an app."
    mems = extract_memories(text, subject="Demo", source_id="test")
    ledger = MemoryLedger("Demo")
    ledger.add_candidates(mems)
    summary = ledger.summary()
    assert summary["candidate_count"] >= 2
    assert summary["block_count"] >= 1


def test_context_pack_has_allowed_memories():
    text = "The user prefers concise answers.\nConstraint: never store passwords."
    mems = extract_memories(text, subject="Demo", source_id="test")
    ledger = MemoryLedger("Demo")
    ledger.add_candidates(mems)
    pack = ledger.context_pack()
    assert pack["context_pack_version"].startswith("dikwp")
    assert len(pack["allowed_memories"]) >= 1


def test_static_audit_passes():
    root = Path(__file__).resolve().parents[1] / "src"
    report = audit_source_tree(root)
    assert report["pass"] is True
