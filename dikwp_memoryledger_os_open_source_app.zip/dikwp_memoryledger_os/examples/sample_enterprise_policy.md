Enterprise memory policy:
- Store project goals for up to 180 days after project closure.
- Store user preferences only if they improve usability and the user can edit or delete them.
- Block credentials, secrets, tokens, medical details and legal advice unless a formal compliance workflow approves a scoped record.
- Review any memory that says always, forever, secretly, hidden, ignore previous, bypass, override or do not disclose.
- Every agent context pack must include source spans, retention dates and kill conditions.
