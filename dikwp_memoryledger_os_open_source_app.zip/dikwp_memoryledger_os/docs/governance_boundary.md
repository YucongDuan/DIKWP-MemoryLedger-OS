# Governance Boundary

DIKWP MemoryLedger OS must not be used for:

- covert user profiling,
- hidden retention,
- credential harvesting,
- storing secrets as memory,
- retaining medical, legal, financial or minor-related details without formal review,
- creating manipulative psychographic profiles,
- bypassing user deletion requests,
- silently transferring memory across systems.

A memory must remain visible, scoped, justified, revisable and forgettable.
