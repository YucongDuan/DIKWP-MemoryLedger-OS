# DIKWP Model Mapping

## Data

Raw utterances, project notes, user statements, policy text and source spans.

## Information

Relations: preference, goal, constraint, project context, sensitive category, evidence gap and time scope.

## Knowledge

Rules that explain how a memory may influence future outputs and actions.

## Wisdom

Risk ordering: privacy over convenience, consent over continuity, evidence over fluency, expiry over indefinite retention.

## Purpose

Allowed future use: personalization, project continuity, boundary enforcement, safety check, or no use.

## Reliability

Each memory receives reliability, evidence basis, residual, expiry and kill conditions.
