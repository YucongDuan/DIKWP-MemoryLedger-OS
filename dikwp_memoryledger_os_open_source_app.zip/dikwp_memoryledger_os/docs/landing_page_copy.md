# Landing Page Copy

## DIKWP MemoryLedger OS

**AI memory should be useful, not invisible.**

Persistent memory makes AI assistants more helpful, but unmanaged memory creates privacy, trust and safety risks. DIKWP MemoryLedger OS turns memory into an auditable ledger: what is remembered, why it is remembered, how long it lasts, what evidence supports it, and when it must be deleted.

### For developers

Drop a memory governance layer into your agents, assistants and MCP context workflows.

### For enterprises

Control persistent memory before it becomes a compliance and trust problem.

### For users

See, edit, export and delete what AI systems remember about you.
