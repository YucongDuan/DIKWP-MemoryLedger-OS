# Architecture

DIKWP MemoryLedger OS contains six layers.

## 1. Input Layer

Accepts text notes, transcripts, chat logs, project notes and policy snippets.

## 2. Memory Extraction Layer

A heuristic parser extracts candidate memories and classifies them as preference, goal, constraint, project context, sensitive, credential-like, poisoning instruction, unsupported claim, or general context.

## 3. DIKWP Registration Layer

Every candidate becomes C=(D,I,K,W,P,R):

- D: source fragment and subject.
- I: relation, type and time scope.
- K: memory mechanism and rule.
- W: value boundary, sensitivity and review norm.
- P: allowed future use and purpose risk.
- R: reliability, evidence, expiry, kill conditions and residual.

## 4. Risk and Consent Layer

The risk engine determines allow / review / block based on memory type, covert-retention signals, sensitivity and evidence state.

## 5. Ledger Output Layer

Produces:

- memory ledger,
- memory risk report,
- purpose continuity map,
- governed context pack,
- DSAR-style export bundle,
- recommendations.

## 6. Agent Integration Layer

The context pack can be consumed by agent runtimes, RAG systems, MCP servers, or enterprise AI assistants as a bounded memory object. It is not a hidden memory store.
