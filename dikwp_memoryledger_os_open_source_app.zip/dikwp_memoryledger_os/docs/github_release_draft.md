# GitHub Release Draft

## DIKWP MemoryLedger OS v0.1.0

This first release provides a local CLI and optional Streamlit dashboard for AI memory governance.

### Highlights

- Extract candidate memories from text.
- Classify memory risk.
- Register memories as DIKWP objects.
- Generate memory ledger, purpose map, context pack and DSAR export.
- Block credential-like and poisoning memories by default.
- Preserve DIKWP / Yucong Duan attribution through NOTICE and CITATION.cff.

### Boundary

This is not a covert profiling tool. It is a memory sovereignty and governance layer.
