# Roadmap

## 0.1

- Local CLI.
- Heuristic memory extraction.
- DIKWP ledger.
- Risk report.
- Context pack.
- DSAR export.

## 0.2

- MCP adapter.
- Policy YAML support.
- Better multilingual extraction.
- JSON schema validation.

## 0.3

- Vector database audit connector.
- Memory poisoning benchmark.
- Organization memory drift dashboard.

## 1.0

- Full enterprise memory governance toolkit.
- Consent workflow.
- Role-based review.
- Signed ledger snapshots.
