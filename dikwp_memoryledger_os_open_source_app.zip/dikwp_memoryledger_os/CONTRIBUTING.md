# Contributing

Contributions are welcome if they preserve the project boundary: explicit, consented, auditable memory governance.

Do not contribute features for covert profiling, hidden retention, credential harvesting, surveillance, or bypassing user deletion requests.

Recommended contribution areas:

- Better memory classification.
- Connector adapters for agent frameworks.
- MCP-compatible context pack generation.
- Enterprise policy templates.
- Localization.
- Evaluation datasets for memory poisoning and stale-memory risk.
